  import React, { Component } from 'react';

  class NumberPad extends Component {
    render() {

    const style = {
      borderRadius:'30%',
      width:'40px',
      height:'40px',
      padding:'3px',
      color:'blue',
      border:'1px solid lightblue',
      margin:'2px',
      cursor:'pointer'
    }

      return (
        <div>
        <button className="btn" name="CE" onClick={e => this.props.onClick(e.target.name)} style={style}>CE</button>
        <button className="btn" name="C" onClick={e => this.props.onClick(e.target.name)} style={style}>C</button>
        <button className="btn" name="(" onClick={e => this.props.onClick(e.target.name)} style={style}>(</button>
        <button className="btn" name=")" onClick={e => this.props.onClick(e.target.name)} style={style}>)</button><br/>
        

        <button className="btn" name="1" onClick={e => this.props.onClick(e.target.name)} style={style}>1</button>
        <button className="btn" name="2" onClick={e => this.props.onClick(e.target.name)} style={style}>2</button>
        <button className="btn" name="3" onClick={e => this.props.onClick(e.target.name)} style={style}>3</button>
        <button className="btn" name="+" onClick={e => this.props.onClick(e.target.name)} style={style}>+</button><br/>
        

        <button className="btn" name="4" onClick={e => this.props.onClick(e.target.name)} style={style}>4</button>
        <button className="btn" name="5" onClick={e => this.props.onClick(e.target.name)} style={style}>5</button>
        <button className="btn" name="6" onClick={e => this.props.onClick(e.target.name)} style={style}>6</button>
        <button className="btn" name="-" onClick={e => this.props.onClick(e.target.name)} style={style}>-</button><br/>


        <button className="btn" name="7" onClick={e => this.props.onClick(e.target.name)} style={style}>7</button>
        <button className="btn" name="8" onClick={e => this.props.onClick(e.target.name)} style={style}>8</button>
        <button className="btn" name="9" onClick={e => this.props.onClick(e.target.name)} style={style}>9</button>
        <button className="btn" name="*" onClick={e => this.props.onClick(e.target.name)} style={style}>x</button><br/>


        <button className="btn" name="." onClick={e => this.props.onClick(e.target.name)} style={style}>.</button>
        <button className="btn" name="0" onClick={e => this.props.onClick(e.target.name)} style={style}>0</button>
        <button className="btn" name="/" onClick={e => this.props.onClick(e.target.name)} style={style}>/</button>
        <button className="btn" name="=" onClick={e => this.props.onClick(e.target.name)} style={style}>=</button><br/>
        </div>
      )
    }
  }

  export default NumberPad;